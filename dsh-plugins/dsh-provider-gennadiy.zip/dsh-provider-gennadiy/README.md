# Провайдер Gennadiy для DeepSeek Harness

**dsh-provider-gennadiy** — плагин для [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness), который подключает корпоративный шлюз **Gennadiy** (OpenAI-совместимый, семейство ai-platform): маршрут `gennadiy`, проверенный каталог моделей, корпоративный TLS CA и **авторизация через Keycloak с авто-обновлением токена**.

**Установка = два шага:** войти через `gennadiy auth login` и поставить плагин. Файлы конфигурации править не нужно — плагин всё прописывает сам и сам держит ключ актуальным.

## Что даёт

- Маршрут `gennadiy` («Gennadiy») в селекторе моделей — сразу после установки.
- 3 chat-модели шлюза с лимитами, сверенными через `GET /models` (2026-11-06).
- Модель `deepseek-v4.1-flash` объявлена мультимодальной (текст + изображения); tool calling и поток размышлений (`reasoning_content`) проверены живым запросом.
- Авторизация Keycloak без ручного копирования токенов: плагин читает CLI-стор `gennadiy` и сам обновляет ключ в credential store (access token живёт ~30 минут).
- Доверие корпоративному CA (без него все запросы падают с `TRANSPORT`).
- Полный редактор маршрута в Settings → Models — **включая поле API key**, список моделей, Base URL.

## Установка

1. Откройте **Settings → Plugins** в DeepSeek Harness. Поле установки принимает npm-пакеты, Git-репозитории и локальные каталоги — укажите источник одним из способов:
   - **локальный каталог**: скопируйте папку `dsh-provider-gennadiy` на машину и вставьте её путь;
   - **Git-репозиторий**: вставьте URL репозитория (удобно, когда плагин лежит в общем git);
   - **tarball**: соберите `npm pack` и укажите путь к `.tgz`.

   Нажмите «Установить».

2. Если ещё не входили — выполните в терминале **`gennadiy auth login`** (см. следующий раздел).

Всё. Плагин при загрузке сам прописывает маршрут (с каталогом моделей) в запись `llm-pi-ai` профиля через штатный ConfigEditor — тот же путь, которым пишет сама страница Models. Существующие маршруты (`mimo`, `kimi-api` и др.) не затрагиваются; повторная загрузка ничего не дублирует.

Без VPN до внутренней сети шлюз `gennadiy-test.kube.severstal.severstalgroup.com` недоступен — запросы будут падать по таймауту.

## Вход: `gennadiy auth login`

Авторизация шлюза — Keycloak JWT, а не статический sk-ключ. Токены выдаёт SSO `https://sso-id-test-int.severstal.com` (realm `common`, client `gennadiy-df`), и они живут в CLI-сторе `gennadiy`:

```
~/.local/share/gennadiy/auth.json   (учитывается XDG_DATA_HOME)
→ { "keycloak": { "access": "...", "refresh": "...", "expires": 1793909007371, "email": "..." } }
```

1. Выполните `gennadiy auth login` в терминале — тот же Keycloak SSO, что используют CLI и Harbor. Порядок с установкой плагина не важен: плагин подхватит токен при загрузке и по таймеру.
2. CLI и плагин делят одну сессию: вход в CLI = вход в харнессе. Если вы уже вошли в `gennadiy` (или в Harbor с Gennadiy-провайдером) — отдельный вход не нужен.

Пока токен не получен, запросы падают с `MISSING_CREDENTIAL` — это ожидаемое «fail-loud» поведение.

## Как устроен token-refresh

Маршрут `llm-pi-ai` шлёт один статический ключ (`apiKeyEnv`) с каждым запросом, а access token Keycloak живёт ~30 минут. Поэтому плагин сам поддерживает актуальность ключа (`keepCredentialFresh` в `index.js`):

- **На загрузке и по таймеру** (ориентир — за ~5 минут до истечения access token, плюс перепроверка каждые ~5 минут) плагин читает CLI-стор `gennadiy`. Если токен обновил другой процесс (CLI и Harbor делят стор) — берётся его значение.
- **Токена нет или он скоро истечёт** — `refresh_token` grant: `POST {sso}/realms/common/protocol/openid-connect/token` (`grant_type=refresh_token`, `client_id=gennadiy-df`, `scope offline_access`). Свежий access token и **ротированный refresh token** записываются обратно в CLI-стор и в credential store (`GENNADIY_API_KEY`) через сервис `credentials`. Запись обратно обязательна: Keycloak при каждом refresh выдаёт новый refresh token, и без записи следующий refresh (в т.ч. из CLI) сломался бы.
- **Приоритет источников ключа:** живой токен из CLI-стора → `refresh_token` grant → `secrets/api-key` (опциональный статический фолбэк, как у плагина davinci: файл при наличии владеет ключом и пересидирует его при каждой загрузке).
- **Стора нет или refresh отклонён** (`invalid_grant` — offline-сессия истекла) — в лог пишется понятное сообщение: **«выполните `gennadiy auth login`»** (плюс путь к CLI-стору для отладки).

## Каталог моделей

Каталог **сверен с `GET https://gennadiy-test.kube.severstal.severstalgroup.com/gennadiy/v1/models` 2026-11-06** (нужен VPN). Шлюз Геннадий отдаёт подмножество каталога ai-platform — три модели:

| Модель | id в шлюзе | Контекст (`max_input_tokens`) | Вывод (`max_output_tokens`) |
|---|---|---|---|
| DeepSeek V4.1 Flash (текст+изображения) | `deepseek-v4.1-flash` | 1 048 576 | 1 048 576 |
| GLM-5.3 | `glm-5.3` | 524 288 | 524 288 |
| Qwen3.8 27B | `qwen3.8-27b` | 262 144 | 262 144 |

Лимиты взяты как их объявляет шлюз (`max_input_tokens` / `max_output_tokens`). При обновлении шлюза сверяйте снова с `GET /models`. Каталог — обычные данные в записи маршрута: дописать/поправить модели можно прямо в редакторе строки (**Settings → Models → «Gennadiy» → «Редактировать»**) или в массиве `MODELS` в `index.js` — больше ничего от него не зависит.

## TLS / корпоративный CA

Шлюз обслуживает сертификат, подписанный корпоративным CA (`Severstal Internal CA` ← корень `SeverstalGroupRoot`). Корень установлен в keychain macOS, но его нет в CA-бандле Node — запросы из харнесса падают с `SELF_SIGNED_CERT_IN_CHAIN`, что в UI выглядит как ошибка `Connection error. (code: TRANSPORT)`.

Поэтому `index.js` при загрузке добавляет цепочку CA из `certs/severstal-ca.pem` в доверенные сертификаты процесса (`tls.setDefaultCACertificates`, системные и публичные CA сохраняются). Настраивать ничего не нужно; при смене корпоративного CA обновите файл в `certs/` (тот же файл, что у плагина `dsh-provider-severstal-davinci`).

## Как это устроено

- `cordis.patch.yml` вставляет один entry (`llm-pi-ai-gennadiy`), чей модуль (`index.js`) при загрузке делает три вещи: расширяет доверие CA процесса; прописывает маршрут `gennadiy` (каталог моделей зашит в модуле) в запись `llm-pi-ai` профиля через сервис `configEditor` (штатный путь Settings → Models, с валидацией, откатом и hot-reload); держит ключ `GENNADIY_API_KEY` в credential store синхронным с Keycloak-сессией CLI-стора (см. «Как устроен token-refresh»).
- Никакого второго монтажа LLM-адаптера нет: маршрут обслуживает штатный адаптер `llm-pi-ai` профиля — поэтому нет коллизий каталога/авторизаций и нет npm-зависимостей.
- Маршрут обязан жить в namespace `llm-pi-ai`: страница Settings → Models рисует поле API key только для провайдеров этого namespace (жёсткая раскладка `layoutOf` в клиенте). Поэтому плагин «переселяет» маршрут именно туда, а не объявляет его в собственном entry.

## Проверка

1. `gennadiy auth login` — в CLI-сторе появится запись `keycloak` с access/refresh.
2. В Settings → Models появится строка «Gennadiy» (зелёная точка = ключ синхронизирован из CLI-стора).
3. Выберите модель (например, DeepSeek V4.1 Flash) в селекторе моделей сессии и отправьте запрос.
4. Попросите что-нибудь, требующее инструмента — должен прийти tool-call и стрим размышлений.

## Совместимость

Повторяет устройство плагина `dsh-provider-severstal-davinci` (проверен на DeepSeek Harness 0.2.2-rc.1). Плагин не зависит от внутренних пакетов приложения, кроме публичного API сервисов `configEditor`/`credentials`/`hmr`. Авторизация (refresh_token grant, ротация refresh-токена, запись в CLI-стор) проверена живым запуском 2026-11-06; при обновлении шлюза обновите лимиты моделей (источник — `GET /models`).

## Troubleshooting

- Ошибка `Connection error.` с `code: TRANSPORT` — почти всегда TLS или сеть: проверьте VPN до внутренней сети и актуальность `certs/severstal-ca.pem`.
- `MISSING_CREDENTIAL` или в логе «нет живого токена Keycloak … выполните `gennadiy auth login`» — CLI-стор пуст или токен истёк: выполните `gennadiy auth login` (или положите статический ключ в `secrets/api-key`, см. `secrets/api-key.example`).
- В логе «refresh_token grant rejected: … invalid_grant» — offline-сессия Keycloak истекла или была отозвана; токен больше не обновляется автоматически — снова `gennadiy auth login`.
- Ключ «мигает» между значениями — проверьте, что не работают два процесса с разными CLI-сторами (разный `XDG_DATA_HOME`); плагин всегда берёт значение из своего стора.
- Маршрут не появляется в селекторе — посмотрите `debug.log` рядом с плагином: там пишутся причины (например, конфликт home-patch). Проверьте, что бандл установлен и включён (Settings → Plugins).
- Запросы падают по таймауту — нет VPN до внутренней сети (`gennadiy-test.kube.severstal.severstalgroup.com`).
