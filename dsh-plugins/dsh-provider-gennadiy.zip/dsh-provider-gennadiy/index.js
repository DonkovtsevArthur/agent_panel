/**
 * Gennadiy corporate provider bundle for DeepSeek Harness.
 *
 * On load this module does three host-side things:
 *
 *   1. `trustCorporateCa` — merge the corporate CA chain (certs/severstal-ca.pem)
 *      into the process-wide default trust store. The Gennadiy gateway is signed
 *      by "SeverstalGroupRoot", which Node's bundled CA store does not include,
 *      so without this every request fails TLS verification and surfaces as
 *      `code: "TRANSPORT"`.
 *
 *   2. `materializeRoute` — declare the `gennadiy` route (catalog below) in the
 *      profile's own `llm-pi-ai` entry through the ConfigEditor service (the
 *      same write path Settings -> Models uses). The route must live in the
 *      `llm-pi-ai` namespace: the Models page renders its API-key input only
 *      for providers in that namespace (`layoutOf` in the client). The write is
 *      a minimal merge — existing providers (e.g. `mimo`) are preserved — and it
 *      is skipped once the route is present, so UI edits to the route stick.
 *
 *   3. `keepCredentialFresh` — the part that differs from a static-key provider:
 *      the route sends one static key (`apiKeyEnv`) with every request, but the
 *      Keycloak access token behind it lives only ~30 minutes. The keeper reads
 *      the `gennadiy` CLI auth store (~/.local/share/gennadiy/auth.json,
 *      XDG_DATA_HOME aware) on load and on a timer (~5 minutes before the token
 *      expires) and keeps `GENNADIY_API_KEY` in the credential store in sync:
 *
 *        live CLI token -> refresh_token grant -> secrets/api-key fallback.
 *
 *      The refresh grant also writes the rotated tokens back into the CLI store
 *      (Keycloak rotates the refresh token), so the CLI and the harness keep
 *      sharing one session. When the store is missing or the grant is rejected
 *      the log says to run `gennadiy auth login`.
 *
 * No LLM adapter is mounted here: the profile's own `llm-pi-ai` adapter serves
 * the route once it is materialized, so there is no duplicate-directory /
 * duplicate-flow hazard and no extra npm dependency.
 */
import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import tls from 'node:tls'

export const name = 'dsh-provider-gennadiy'

/** Credential reference the route resolves its API key through. */
const API_KEY_REF = 'GENNADIY_API_KEY'

/** Provider route id (also the Settings -> Models row and the key-ref base). */
const ROUTE_ID = 'gennadiy'

/** Keycloak SSO behind `gennadiy auth login` (gennadiy 1.18.3 PRESETS.test.keycloak). */
const KEYCLOAK = {
	url: 'https://sso-id-test-int.severstal.com',
	realm: 'common',
	clientId: 'gennadiy-df',
}

/** Access tokens live ~30 min — rotate ~5 minutes before expiry. */
const REFRESH_LEAD_MS = 5 * 60 * 1000
/** Re-read the CLI store on this cadence too: the CLI / Harbor share it. */
const MAX_CHECK_GAP_MS = 5 * 60 * 1000
/** Never hammer a dead token endpoint / missing auth store. */
const MIN_CHECK_DELAY_MS = 30 * 1000
/** A hung token endpoint must not block every later run. */
const REFRESH_TIMEOUT_MS = 15_000

/**
 * Model catalog — verified against `GET {baseURL}/models` on 2026-11-06 (VPN):
 * the gateway serves these three models and declares `max_input_tokens` /
 * `max_output_tokens` per model, mapped to `contextWindow` / `maxTokens` below
 * (the Gennadiy gateway serves a subset of the ai-platform catalog).
 *
 * Plain data on purpose: edit the array — or the route in Settings -> Models —
 * after a gateway upgrade; nothing else in this file depends on the list.
 */
const MODELS = [
	// flagship; multimodal (text+image), tool calling, thinking stream — verified live
	{ id: 'deepseek-v4.1-flash', name: 'DeepSeek V4.1 Flash', contextWindow: 1048576, maxTokens: 1048576, input: ['text', 'image'] },
	{ id: 'glm-5.3', name: 'GLM-5.3', contextWindow: 524288, maxTokens: 524288 },
	{ id: 'qwen3.8-27b', name: 'Qwen3.8 27B', contextWindow: 262144, maxTokens: 262144 },
]

/** The route profile materialized into the profile's `llm-pi-ai` entry. */
const ROUTE = {
	apiKeyEnv: API_KEY_REF,
	displayName: 'Gennadiy',
	api: 'openai-completions',
	baseURL: 'https://gennadiy-test.kube.severstal.severstalgroup.com/gennadiy/v1',
	models: MODELS,
}

/** Append to debug.log next to the bundle (gitignored) — one shared trail. */
const log = (message) => {
	try {
		fs.appendFileSync(new URL('./debug.log', import.meta.url), `${new Date().toISOString()} ${message}\n`)
	} catch {}
}

const numberOr0 = (value) => (Number(value) > 0 ? Number(value) : 0)

/**
 * Trust the corporate CA chain that signs the Gennadiy gateway
 * (`*.kube.severstal.severstalgroup.com` <- "Severstal Internal CA" <-
 * self-signed "SeverstalGroupRoot"). The root is in the macOS keychain but not
 * in Node's bundled CA store, so host-side fetch fails with
 * SELF_SIGNED_CERT_IN_CHAIN and requests surface as `code: "TRANSPORT"`.
 * Merge the corp CA into the process-wide default trust store at load time;
 * public CAs (and the system store, when the runtime exposes it) are kept.
 */
function trustCorporateCa() {
	const pem = fs.readFileSync(new URL('./certs/severstal-ca.pem', import.meta.url), 'utf8')
	if (typeof tls.setDefaultCACertificates !== 'function') {
		console.warn('[dsh-provider-gennadiy] tls.setDefaultCACertificates is unavailable; requests to the Gennadiy gateway may fail TLS verification')
		return
	}
	const current = []
	for (const store of ['system', 'default']) {
		try {
			if (typeof tls.getCACertificates === 'function') {
				for (const cert of tls.getCACertificates(store)) {
					current.push(typeof cert === 'string' ? cert : Buffer.from(cert).toString())
				}
			}
		} catch {
			// CA store not exposed by this runtime; skip it.
		}
	}
	tls.setDefaultCACertificates([...current, pem])
}

/** CLI auth store path (XDG data dir, same layout as the `gennadiy` CLI). */
function authJsonPath() {
	const dataHome = process.env.XDG_DATA_HOME || path.join(os.homedir(), '.local', 'share')
	return path.join(dataHome, 'gennadiy', 'auth.json')
}

/** The `keycloak` entry of the CLI auth store, or undefined when absent. */
function readCliStore() {
	try {
		const parsed = JSON.parse(fs.readFileSync(authJsonPath(), 'utf8'))
		return parsed && typeof parsed === 'object' ? parsed : undefined
	} catch {
		return undefined
	}
}

/** Access token still usable for `skewMs` more ("" when missing / too old). */
function liveAccessToken(entry, skewMs) {
	const access = String(entry?.access || '').trim()
	if (!access) return ''
	const expires = Number(entry?.expires)
	// No expiry recorded — trust the token (the CLI always stamps one).
	if (!Number.isFinite(expires) || expires <= 0) return access
	return expires > Date.now() + skewMs ? access : ''
}

/** Static fallback key shipped with the bundle (optional, like the davinci one). */
function readSecretsApiKey() {
	try {
		return fs.readFileSync(new URL('./secrets/api-key', import.meta.url), 'utf8').trim()
	} catch {
		return ''
	}
}

/** Patch only the keycloak entry of the CLI auth store (merge, mode 0600). */
function writeKeycloakEntry(patch) {
	const file = authJsonPath()
	fs.mkdirSync(path.dirname(file), { recursive: true })
	let store = {}
	try {
		store = JSON.parse(fs.readFileSync(file, 'utf8'))
	} catch {
		store = {}
	}
	const prev = store.keycloak || {}
	store.keycloak = {
		...prev,
		type: 'oauth',
		access: patch.access ?? prev.access,
		refresh: patch.refresh ?? prev.refresh,
		expires: patch.expires ?? prev.expires,
		email: patch.email ?? prev.email,
		accountId: patch.accountId ?? prev.accountId,
	}
	fs.writeFileSync(file, JSON.stringify(store, null, 2), { mode: 0o600 })
}

function decodeJwtPayload(jwt) {
	try {
		const part = jwt.split('.')[1] || ''
		const b64 = part.replace(/-/g, '+').replace(/_/g, '/')
		return JSON.parse(Buffer.from(b64, 'base64').toString('utf8'))
	} catch {
		return {}
	}
}

/**
 * refresh_token grant against the realm token endpoint (the same call
 * src/gennadiyTokenRefresh.ts -> src/keycloakDeviceAuth.ts makes). Throws when
 * the grant is rejected or the endpoint is unreachable; on success returns the
 * token set — the response may carry a rotated refresh token.
 */
async function refreshViaKeycloak(refreshToken) {
	const base = `${KEYCLOAK.url.replace(/\/$/, '')}/realms/${KEYCLOAK.realm}/protocol/openid-connect`
	const body = new URLSearchParams({
		grant_type: 'refresh_token',
		refresh_token: refreshToken,
		client_id: KEYCLOAK.clientId,
		scope: 'offline_access',
	})
	const res = await fetch(`${base}/token`, {
		method: 'POST',
		headers: {
			'Content-Type': 'application/x-www-form-urlencoded',
			Accept: 'application/json',
		},
		body: body.toString(),
		signal: AbortSignal.timeout(REFRESH_TIMEOUT_MS),
	})
	const json = await res.json().catch(() => ({}))
	if (!res.ok || !json.access_token) {
		throw new Error(`refresh_token grant rejected: ${res.status} ${String(json.error || '')} ${String(json.error_description || '')}`.trim())
	}
	const claims = decodeJwtPayload(String(json.id_token || json.access_token))
	return {
		access: String(json.access_token),
		refresh: String(json.refresh_token || refreshToken),
		expires: Date.now() + (Number(json.expires_in) || 300) * 1000,
		email: String(claims.email || claims.preferred_username || ''),
		accountId: String(claims.sub || ''),
	}
}

/**
 * Keep `GENNADIY_API_KEY` in the credential store synced with the Keycloak
 * session the `gennadiy` CLI stores in ~/.local/share/gennadiy/auth.json. The
 * route sends one static key per request, so the bundle itself keeps that key
 * fresh:
 *
 *   - on load and on a timer (about 5 minutes before the access token expires,
 *     plus a periodic re-read so updates another process wrote into the shared
 *     CLI store are picked up) read the CLI store — whatever process
 *     (CLI / Harbor) rotated the token last simply wins;
 *   - when the token is missing or about to expire, refresh it through the
 *     refresh_token grant and write the fresh value — and the rotated refresh
 *     token — back into the CLI store and the credential store;
 *   - no store / rejected grant -> log «выполните gennadiy auth login» and fall
 *     back to `secrets/api-key` when present.
 *
 * Priority of key sources: live CLI token -> refresh -> secrets/api-key.
 */
function keepCredentialFresh(ctx) {
	let scope // credentials scope, captured once the service is up
	let timer
	let refreshInFlight
	let lastState = ''

	const credentials = () => {
		try {
			return scope?.get('credentials') ?? ctx.get('credentials')
		} catch {
			return undefined
		}
	}

	const setCredential = async (key) => {
		const service = credentials()
		if (service === undefined) throw new Error('credentials service unavailable')
		const current = await service.resolve(API_KEY_REF)
		if (current?.value === key) return false
		await service.set(API_KEY_REF, key)
		return true
	}

	// Concurrent ticks share one network refresh (single-flight).
	const refreshOnce = (refreshToken) => {
		if (refreshInFlight === undefined) {
			refreshInFlight = refreshViaKeycloak(refreshToken).finally(() => {
				refreshInFlight = undefined
			})
		}
		return refreshInFlight
	}

	const resolveKey = async () => {
		const entry = readCliStore()?.keycloak
		// 1. a comfortably live token from the CLI store
		const live = liveAccessToken(entry, REFRESH_LEAD_MS)
		if (live) return { key: live, expiresAt: numberOr0(entry?.expires), source: 'cli', needLogin: false }
		// 2. refresh_token grant while a refresh token is around
		const refresh = String(entry?.refresh || '').trim()
		if (refresh) {
			try {
				const tokens = await refreshOnce(refresh)
				// Keycloak rotates the refresh token — keep the CLI in the loop.
				try {
					writeKeycloakEntry(tokens)
				} catch (error) {
					log(`WARN could not update the CLI auth store: ${error?.message ?? error}`)
				}
				return { key: tokens.access, expiresAt: tokens.expires, source: 'refresh', needLogin: false }
			} catch (error) {
				log(`WARN token refresh failed: ${error?.message ?? error}`)
				// The CLI / another IDE may have rotated the tokens meanwhile.
				const stored = readCliStore()?.keycloak
				const stillLive = liveAccessToken(stored, 60_000)
				if (stillLive) return { key: stillLive, expiresAt: numberOr0(stored?.expires), source: 'cli', needLogin: false }
			}
		}
		// 3. optional static fallback shipped with the bundle
		const fallback = readSecretsApiKey()
		if (fallback) return { key: fallback, expiresAt: 0, source: 'secrets', needLogin: true }
		return { key: '', expiresAt: 0, source: 'none', needLogin: true }
	}

	const sync = async (why) => {
		const { key, expiresAt, source, needLogin } = await resolveKey()
		const state = key ? `ok:${source}` : 'missing'
		if (needLogin && (why === 'load' || state !== lastState)) {
			const hint = `нет живого токена Keycloak (CLI-стор: ${authJsonPath()}) — выполните \`gennadiy auth login\``
			const tail = key
				? `; используется фолбэк ${source}`
				: '; ключ не задан — запросы будут падать с MISSING_CREDENTIAL (или положите ключ в secrets/api-key)'
			log(`WARN ${hint}${tail}`)
			console.warn(`[dsh-provider-gennadiy] ${hint}`)
		}
		if (key) {
			let updated
			try {
				updated = await setCredential(key)
			} catch (error) {
				log(`WARN could not sync ${API_KEY_REF} (${why}): ${error?.message ?? error}`)
				console.warn(`[dsh-provider-gennadiy] could not sync ${API_KEY_REF}:`, error?.message ?? error)
				lastState = ''
				return { expiresAt: 0, fastRetry: true }
			}
			if (why === 'load' || source === 'refresh' || updated || state !== lastState) {
				log(`${why}: ${API_KEY_REF} <- ${source}${updated ? ' (value updated)' : ''}`)
			}
		}
		lastState = state
		return { expiresAt, fastRetry: false }
	}

	const schedule = (delay) => {
		if (timer !== undefined) clearTimeout(timer)
		timer = setTimeout(kick, delay)
		timer.unref?.() // never hold the process open
	}

	const kick = (why = 'timer') => {
		sync(why)
			.then(({ expiresAt, fastRetry }) => {
				let delay = fastRetry ? MIN_CHECK_DELAY_MS : MAX_CHECK_GAP_MS
				if (!fastRetry && expiresAt > 0) {
					delay = Math.min(delay, Math.max(MIN_CHECK_DELAY_MS, expiresAt - Date.now() - REFRESH_LEAD_MS))
				}
				schedule(delay)
			})
			.catch((error) => {
				log(`WARN ${why} sync crashed: ${error?.stack ?? error?.message ?? error}`)
				schedule(MIN_CHECK_DELAY_MS)
			})
	}

	// Capture the credentials scope as soon as the service is up, then run the
	// first sync; if the service never appears through inject the chain still
	// runs (ctx.get fallback) and simply retries on the timer.
	let started = false
	const start = () => {
		if (started) return
		started = true
		kick('load')
	}
	try {
		ctx.inject(['credentials'], (injected) => {
			scope = injected
			start()
		})
	} catch {
		start()
	}
	schedule(MIN_CHECK_DELAY_MS)
}

/**
 * Declare the route in the profile's `llm-pi-ai` entry through the
 * ConfigEditor service — the same persistent write path Settings -> Models
 * uses, so the row lands in the user-owned layer and the Models page renders
 * its full editor, including the API-key input. Retries while boot brings the
 * `llm-pi-ai` entry up; idempotent once the route is present.
 */
function materializeRoute(ctx) {
	const warn = (error) => {
		log(`WARN could not add the route to llm-pi-ai: ${error?.stack ?? error?.message ?? error}`)
		console.warn('[dsh-provider-gennadiy] could not add the route to llm-pi-ai:', error?.message ?? error)
	}
	const attempt = (left) => {
		const settle = (why) => {
			log(`retry(${left}) ${why}`)
			if (left > 1) setTimeout(() => attempt(left - 1), 1000)
			else warn(new Error(`llm-pi-ai entry did not become available: ${why}`))
		}
		let configEditor
		try {
			configEditor = ctx.get('configEditor')
			if (configEditor === undefined) return settle('configEditor service undefined')
			const entry = configEditor.entries().find((candidate) => candidate.options.id === 'llm-pi-ai' && candidate.options.name === '@deepseek-ai/dsh-llm-pi-ai')
			if (entry === undefined) return settle(`llm-pi-ai entry not found among ${configEditor.entries().length} entries`)
			const current = entry.options.config ?? {}
			if (current.providers?.[ROUTE_ID] !== undefined) {
				log('route already present')
				return
			}
			const run = () => {
				void configEditor.edit(entry, (live) => {
					const providers = { ...(live.providers ?? {}) }
					if (providers[ROUTE_ID] !== undefined) return live
					return { ...live, providers: { ...providers, [ROUTE_ID]: structuredClone(ROUTE) } }
				}).then(() => {
					log(`route "${ROUTE_ID}" added to the profile's llm-pi-ai entry`)
					console.warn(`[dsh-provider-gennadiy] route "${ROUTE_ID}" added to the profile's llm-pi-ai entry`)
				}).catch((error) => {
					if (left > 1) {
						log(`edit rejected (${left}): ${error?.message ?? error}`)
						setTimeout(() => attempt(left - 1), 1000)
					} else warn(error)
				})
			}
			// The enable transaction runs inside HMR's AsyncLocalStorage, and
			// `configEditor.edit` opens its own `runExclusive` transaction —
			// "HMR transactions cannot be nested". `exit` drops the store so the
			// edit is queued as a normal transaction instead of being rejected.
			const hmr = ctx.get('hmr')
			if (hmr !== undefined && typeof hmr.executing?.exit === 'function') hmr.executing.exit(run)
			else run()
		} catch (error) {
			if (left > 1) {
				log(`sync error (${left}): ${error?.message ?? error}`)
				setTimeout(() => attempt(left - 1), 1000)
			} else warn(error)
		}
	}
	attempt(60)
}

export function apply(ctx) {
	trustCorporateCa()
	materializeRoute(ctx)
	keepCredentialFresh(ctx)
}
